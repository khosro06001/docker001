#!/bin/bash

# Docker buildx script to build and deploy multi-architecture image
# Builds for both AMD64 and ARM64 architectures

set -e

# Configuration
IMAGE_NAME="your-dockerhub-username/vlm-image-captioning"
TAG="latest"
FULL_IMAGE_NAME="${IMAGE_NAME}:${TAG}"

echo "=== Docker Multi-Architecture Build and Deploy ==="
echo "Image: $FULL_IMAGE_NAME"
echo "Date: $(date)"

# Check if buildx is available
if ! docker buildx version >/dev/null 2>&1; then
    echo "Error: Docker buildx is not available"
    echo "Please install Docker buildx or use Docker Desktop"
    exit 1
fi

# Create and use buildx builder if it doesn't exist
BUILDER_NAME="vlm-builder"
if ! docker buildx inspect $BUILDER_NAME >/dev/null 2>&1; then
    echo "Creating buildx builder: $BUILDER_NAME"
    docker buildx create --name $BUILDER_NAME --driver docker-container --bootstrap
fi

echo "Using buildx builder: $BUILDER_NAME"
docker buildx use $BUILDER_NAME

# Verify required files exist
required_files=("vlm001.py" "requirements.txt" "Dockerfile" "healthcheck.py")
for file in "${required_files[@]}"; do
    if [ ! -f "$file" ]; then
        echo "Error: Required file '$file' not found"
        exit 1
    fi
done

# Login to Docker Hub (if not already logged in)
if ! docker info | grep -q "Username:"; then
    echo "Please login to Docker Hub:"
    docker login
fi

echo ""
echo "=== Building multi-architecture image ==="
echo "This will build for AMD64 and ARM64 architectures"
echo "Building may take 15-30 minutes..."
echo ""

# Build and push multi-architecture image
docker buildx build \
    --platform linux/amd64,linux/arm64 \
    --tag $FULL_IMAGE_NAME \
    --push \
    .

echo ""
echo "=== Build completed successfully! ==="
echo "Image pushed to Docker Hub: $FULL_IMAGE_NAME"
echo ""
echo "To pull and run on Jetson Nano:"
echo "  docker pull $FULL_IMAGE_NAME"
echo ""
echo "To test locally:"
echo "  docker run --rm -it $FULL_IMAGE_NAME"
echo ""
echo "=== Next steps ==="
echo "1. Test the image on your development machine"
echo "2. Deploy to Jetson Nano using the run script"
echo "3. Copy your images to /app/data/ in the container"
