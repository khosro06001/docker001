#!/usr/bin/env python3
"""
Docker health check script
"""

import sys
import torch
import psutil

def main():
    try:
        # Check if Python imports work
        import transformers
        import PIL
        
        # Check memory usage
        memory = psutil.virtual_memory()
        if memory.percent > 95:
            print("UNHEALTHY: Memory usage too high")
            sys.exit(1)
        
        # Check if CUDA is available (on Jetson)
        cuda_available = torch.cuda.is_available()
        print(f"CUDA available: {cuda_available}")
        
        print("HEALTHY")
        sys.exit(0)
        
    except Exception as e:
        print(f"UNHEALTHY: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
